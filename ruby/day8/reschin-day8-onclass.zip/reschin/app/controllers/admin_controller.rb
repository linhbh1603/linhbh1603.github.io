

class AdminController < ActionController::Base
  def dashboard
  end
end
